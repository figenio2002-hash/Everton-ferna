package com.beyondcheats.panel

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 10, 15)
    private val panel = Color.rgb(22, 24, 33)
    private val red = Color.rgb(255, 59, 48)
    private val white = Color.WHITE
    private val options = arrayOf("RT Hook", "RT DEV", "DEV (mais compatível)", "QX10~11.4", "KPM (Neo prctl)")
    private val captures = arrayOf("Ocultar em gravações e capturas", "Visível normalmente")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("beyond_config", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 30, 22, 24); setBackgroundColor(bg) }
        val scroll = ScrollView(this).apply { addView(root) }

        val brand = TextView(this).apply {
            text = "BEYOND CHEATS"; textSize = 27f; setTextColor(white); typeface = Typeface.create("sans-serif-black", Typeface.BOLD); gravity = Gravity.CENTER
        }
        root.addView(brand, matchWrap())
        val subtitle = TextView(this).apply { text = "PAINEL DE CONFIGURAÇÕES"; textSize = 11f; letterSpacing = .22f; setTextColor(red); gravity = Gravity.CENTER; setPadding(0, 6, 0, 26) }
        root.addView(subtitle)

        val status = TextView(this).apply {
            text = "●  PAINEL PRONTO\nConfigurações locais disponíveis"; textSize = 14f; setTextColor(Color.rgb(120, 235, 160)); setPadding(18, 18, 18, 18); setBackgroundColor(panel)
        }
        root.addView(status, fullWidth())
        addLabel(root, "OPÇÃO DE DRIVER")
        val driver = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options)
            setSelection((prefs.getInt("driver", 1).coerceIn(1, 5)) - 1)
        }
        styleSpinner(driver); root.addView(driver, fullWidth())

        addLabel(root, "MODO DE CAPTURA")
        val capture = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, captures)
            setSelection(prefs.getInt("capture", 1).coerceIn(1, 2) - 1)
        }
        styleSpinner(capture); root.addView(capture, fullWidth())

        val save = Button(this).apply {
            text = "SALVAR CONFIGURAÇÕES"; setTextColor(white); setBackgroundColor(red); isAllCaps = false
            setOnClickListener {
                prefs.edit().putInt("driver", driver.selectedItemPosition + 1).putInt("capture", capture.selectedItemPosition + 1).apply()
                Toast.makeText(this@MainActivity, "Configurações salvas neste aparelho!", Toast.LENGTH_SHORT).show()
            }
        }
        val lp = fullWidth(); lp.topMargin = 28; root.addView(save, lp)

        val note = TextView(this).apply {
            text = "INFORMAÇÃO\nEste APK é um painel de preferências. Ele salva as opções no aparelho, mas não carrega drivers de kernel nem executa leitura, alteração ou ocultação de processos. A integração nativa do driver precisa de um componente compatível e autorizado."
            setTextColor(Color.LTGRAY); textSize = 12f; setLineSpacing(5f, 1f); setPadding(16, 18, 16, 18); setBackgroundColor(panel)
        }
        val noteLp = fullWidth(); noteLp.topMargin = 24; root.addView(note, noteLp)
        setContentView(scroll)
    }

    private fun addLabel(root: LinearLayout, text: String) {
        val v = TextView(this).apply { this.text = text; setTextColor(white); textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setPadding(2, 24, 2, 8) }
        root.addView(v)
    }
    private fun styleSpinner(s: Spinner) { s.setPadding(12, 12, 12, 12); s.setBackgroundColor(panel) }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun fullWidth() = LinearLayout.LayoutParams(-1, -2)
}
